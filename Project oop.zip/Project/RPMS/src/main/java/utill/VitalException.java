package utill;

public class VitalException extends Exception{
    public VitalException(String message) {
        super(message);
    }
}
